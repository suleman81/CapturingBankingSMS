package com.suleman.capturingbankingsms.services;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.fxn.stash.Stash;
import com.suleman.capturingbankingsms.DeviceModel;

import org.json.JSONException;
import org.json.JSONObject;

public class MessageReceiver extends BroadcastReceiver {
    String TAG = "MyPhoneStateListener";
    Context context;
    public static final String INFO = "INFO";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "onReceive");
        this.context = context;
        if (intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED") || intent.getAction().equals("com.google.android.gms.rcs.RECEIVE_RCS_MESSAGE")) {
            Log.d(TAG, "onReceive SMS");
            Bundle bundle = intent.getExtras();
            if (bundle != null) {
                Object[] pdus = (Object[]) bundle.get("pdus");
                if (pdus != null) {
                    StringBuilder fullMessage = new StringBuilder();
                    String sender = "";
                    for (Object pdu : pdus) {
                        SmsMessage smsMessage = SmsMessage.createFromPdu((byte[]) pdu);
                        sender = smsMessage.getDisplayOriginatingAddress();
                        fullMessage.append(smsMessage.getMessageBody());
                    }
                    DeviceModel deviceModel = (DeviceModel) Stash.getObject(INFO, DeviceModel.class);
                    if (deviceModel != null)
                        callApi(context, fullMessage.toString(), sender, deviceModel);
                }
            }
        }
    }

    private void callApi(Context context, String notifyMessage, String sender, DeviceModel deviceModel) {
        RequestQueue requestQueue = VolleySingleton.getInstance(this.context).getRequestQueue();
        JSONObject json = new JSONObject();
        try {
            // String imei = getDeviceIMEI(context);
            json.put("channel", sender);
            json.put("sms", notifyMessage);
            json.put("bank_name", deviceModel.bankName);
            json.put("account_title", deviceModel.accountTitle);
            json.put("account_number", deviceModel.accountNumber);
            json.put("department", deviceModel.department_ID);
            json.put("device", deviceModel.device_ID);
            JsonObjectRequest stringRequest = new JsonObjectRequest(Request.Method.POST, "http://3.29.241.160:8000/create", json,
                    response -> {
                        Log.d("TOKEN_CHECK", "Response : " + response.toString());
                    },
                    error -> {
                        Log.e("TOKEN_CHECK", "Error  : " + error.getLocalizedMessage());
                    }
            );
            requestQueue.add(stringRequest);
        } catch (JSONException | SecurityException e) {
            Toast.makeText(context, e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    public String getDeviceIMEI(Context context) {
        String deviceUniqueIdentifier = null;
        try {
            TelephonyManager tm = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
            if (null != tm) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    deviceUniqueIdentifier = tm.getImei();
                } else {
                    deviceUniqueIdentifier = tm.getDeviceId();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (null == deviceUniqueIdentifier || deviceUniqueIdentifier.isEmpty()) {
            deviceUniqueIdentifier = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ANDROID_ID);
        }
        if (deviceUniqueIdentifier == null) deviceUniqueIdentifier = "";

        return deviceUniqueIdentifier;
    }

}